import 'dart:async';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final cameras = await availableCameras();
  runApp(PoseCamApp(cameras: cameras));
}

class PoseItem {
  final String name;
  final String category;
  final IconData icon;
  const PoseItem(this.name, this.category, this.icon);
}

const poses = [
  PoseItem('Đứng thẳng', 'Cơ bản', Icons.accessibility_new),
  PoseItem('Một chân', 'Cơ bản', Icons.directions_walk),
  PoseItem('Tay hông', 'Cơ bản', Icons.accessibility),
  PoseItem('Bước đi', 'Street', Icons.directions_run),
  PoseItem('Ngồi ghế', 'Lifestyle', Icons.event_seat),
  PoseItem('Chân chéo', 'Fashion', Icons.accessibility_new),
  PoseItem('Quay lưng', 'Fashion', Icons.sync),
  PoseItem('Cặp đôi', 'Couple', Icons.favorite_border),
  PoseItem('Du lịch', 'Travel', Icons.flight_takeoff),
  PoseItem('Áo dài', 'VN', Icons.person),
];

class PoseCamApp extends StatelessWidget {
  final List<CameraDescription> cameras;
  const PoseCamApp({super.key, required this.cameras});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'PoseCam',
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: Colors.black, useMaterial3: true),
    home: HomePage(cameras: cameras),
  );
}

class HomePage extends StatefulWidget {
  final List<CameraDescription> cameras;
  const HomePage({super.key, required this.cameras});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String category = 'Tất cả';
  final cats = ['Tất cả','Cơ bản','Fashion','Street','Lifestyle','Couple','Travel','VN'];
  @override
  Widget build(BuildContext context) {
    final filtered = category == 'Tất cả' ? poses : poses.where((p) => p.category == category).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('PoseCam', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.settings_outlined))]),
      body: Column(children: [
        SizedBox(height: 52, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 14), scrollDirection: Axis.horizontal, itemCount: cats.length, separatorBuilder: (_,__)=>const SizedBox(width:8), itemBuilder: (_,i)=>ChoiceChip(label: Text(cats[i]), selected: category==cats[i], onSelected: (_)=>setState(()=>category=cats[i])))),
        Expanded(child: GridView.builder(padding: const EdgeInsets.all(14), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .82), itemCount: filtered.length, itemBuilder: (_,i) {
          final p=filtered[i]; return GestureDetector(onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>CameraPage(cameras: widget.cameras, pose: p))), child: Container(decoration: BoxDecoration(color: const Color(0xff151515), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white12)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Expanded(child: Center(child: Icon(p.icon, size: 92, color: Colors.white70))), Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height:5), Text(p.category, style: const TextStyle(color: Colors.white54)), const SizedBox(height:12)])));
        }))
      ])
    );
  }
}

class CameraPage extends StatefulWidget {
  final List<CameraDescription> cameras; final PoseItem pose;
  const CameraPage({super.key, required this.cameras, required this.pose});
  @override State<CameraPage> createState()=>_CameraPageState();
}
class _CameraPageState extends State<CameraPage> {
  CameraController? controller; int camIndex=0; double opacity=.48, scale=1.0; bool mirrored=false, grid=false, timerOn=false; int countdown=0;
  @override void initState(){super.initState(); _initCamera();}
  Future<void> _initCamera() async { if(widget.cameras.isEmpty)return; controller=CameraController(widget.cameras[camIndex], ResolutionPreset.high, enableAudio:false); await controller!.initialize(); if(mounted)setState((){}); }
  @override void dispose(){controller?.dispose(); super.dispose();}
  Future<void> snap() async { if(controller==null||!controller!.value.isInitialized)return; if(timerOn){for(int i=3;i>0;i--){setState(()=>countdown=i);await Future.delayed(const Duration(seconds:1));}setState(()=>countdown=0);} final file=await controller!.takePicture(); final bytes=await file.readAsBytes(); final result=await ImageGallerySaverPlus.saveImage(Uint8List.fromList(bytes), quality:95, name:'PoseCam_${DateTime.now().millisecondsSinceEpoch}'); if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(result['isSuccess']==true?'Đã lưu ảnh vào thư viện':'Không thể lưu ảnh'))); }
  void switchCam(){if(widget.cameras.length<2)return; camIndex=camIndex==0?1:0; _initCamera();}
  @override Widget build(BuildContext context){
    if(controller==null||!controller!.value.isInitialized)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(body: Stack(fit:StackFit.expand, children:[
      CameraPreview(controller!),
      if(grid) CustomPaint(painter: GridPainter()),
      Center(child: Transform(transform: Matrix4.diagonal3Values(mirrored ? -scale : scale, scale, 1), alignment: Alignment.center, child: Opacity(opacity: opacity, child: CustomPaint(size: const Size(260,520), painter: PosePainter())))),
      if(countdown>0)Center(child: Text('$countdown',style:const TextStyle(fontSize:90,fontWeight:FontWeight.w900))),
      SafeArea(child: Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.close)), Row(children:[IconButton(onPressed:()=>setState(()=>mirrored=!mirrored),icon:const Icon(Icons.flip)),IconButton(onPressed:()=>setState(()=>grid=!grid),icon:const Icon(Icons.grid_4x4)),IconButton(onPressed:switchCam,icon:const Icon(Icons.cameraswitch))])]), const Spacer(),
        Container(padding:const EdgeInsets.fromLTRB(16,8,16,18), decoration:const BoxDecoration(gradient:LinearGradient(begin:Alignment.bottomCenter,end:Alignment.topCenter,colors:[Colors.black87,Colors.transparent])), child:Column(children:[Row(children:[const Icon(Icons.opacity),Expanded(child:Slider(value:opacity,min:.1,max:.9,onChanged:(v)=>setState(()=>opacity=v))),const Icon(Icons.zoom_in),Expanded(child:Slider(value:scale,min:.6,max:1.5,onChanged:(v)=>setState(()=>scale=v)))]),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[IconButton(onPressed:()=>setState(()=>timerOn=!timerOn),icon:Icon(timerOn?Icons.timer:Icons.timer_outlined)),GestureDetector(onTap:snap,child:Container(width:72,height:72,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white,width:5)),child:Container(margin:const EdgeInsets.all(6),decoration:const BoxDecoration(color:Colors.white,shape:BoxShape.circle))),),IconButton(onPressed:()=>setState(()=>scale=1),icon:const Icon(Icons.fit_screen))])]))]))
    ]));
  }
}
class GridPainter extends CustomPainter { @override void paint(Canvas c,Size s){final p=Paint()..color=Colors.white24..strokeWidth=1;for(int i=1;i<3;i++){c.drawLine(Offset(s.width*i/3,0),Offset(s.width*i/3,s.height),p);c.drawLine(Offset(0,s.height*i/3),Offset(s.width,s.height*i/3),p);}}@override bool shouldRepaint(covariant CustomPainter old)=>false;}
class PosePainter extends CustomPainter { @override void paint(Canvas c,Size s){final p=Paint()..color=Colors.white..style=PaintingStyle.stroke..strokeWidth=7..strokeCap=StrokeCap.round;final fill=Paint()..color=Colors.white; final cx=s.width/2; c.drawCircle(Offset(cx,55),28,fill); final path=Path()..moveTo(cx,85)..lineTo(cx,235)..moveTo(cx,115)..lineTo(cx-70,180)..moveTo(cx,115)..lineTo(cx+70,155)..moveTo(cx,235)..lineTo(cx-65,390)..moveTo(cx,235)..lineTo(cx+75,385);c.drawPath(path,p); } @override bool shouldRepaint(covariant CustomPainter old)=>false;}
