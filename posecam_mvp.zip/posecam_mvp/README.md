# PoseCam MVP

Flutter Android MVP for a pose-guide camera app.

## Features
- Pose categories and library
- Camera preview
- White pose overlay
- Overlay opacity and scale
- Mirror overlay
- Grid
- Front/rear camera switch
- 3-second timer toggle
- Save captured camera image to gallery

## Build
1. Install Flutter stable and Android Studio.
2. From this folder run `flutter pub get`.
3. Run `flutter build apk --release`.
4. APK: `build/app/outputs/flutter-apk/app-release.apk`

Note: the included Android Gradle files are a project skeleton; run `flutter create .` in this folder with a matching Flutter stable version if Flutter reports missing generated Gradle/embedding files, then run `flutter pub get` and `flutter build apk --release`.
